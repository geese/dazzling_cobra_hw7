# # dazzling_cobra_hw7

Gisela Chodos

Karl Marble

Jordan Newkirk



Simulates a portion of control software for a vehicle. Takes a sequence of values for the switches and gear shift.

    dazzling_cobra_mod1_hw7.py - Logic of the control software which determines which door(s) opens (if any). 
  
    dazzling_cobra_mod2_hw7.py - Tests the logic from dazzling_cobra_mod1_hw3.py using an imported csv file and displays the values of the switches and gear shift as well as which door(s) open (if any).
  
    dazzling_cobra_task1_hw7.py - gets the file from url containing the van door tests, and sorts them into a dict.
    
Converts a zipcode into a barcode based on the check digit (number which makes the sum of 5 numbers a multiple of 10
)

    dazzling_cobra_mod3_hw7.py - Takes user inputed zipcode and converts into a barcode. Displays zipcode, check digit, and barcode.
  
    dazzling_cobra_mod4_hw7.py - Uses dazzling_cobra_mod3_hw.py to convert zipcodes imported from a csv file into barcodes. Displays zipcode, check digit, and barcode.
